<?php
class Principal extends Controller
{
    public function __construct()
    {
        parent::__construct();
        session_start();
    }
    public function index()
    {

    }
    //view about
    public function about()
    {
        $data['title'] = 'Nuestro Equipo';
        $this->views->getView('principal', "about", $data);
    }

    //vista shop
    public function shop()
    {
        $data['title'] = 'Nuestros Productos';
        $data['productos'] = $this->model->getProductos();
        $this->views->getView('principal', "shop", $data);
    }

    //vista detail
    public function detail($id_producto)
    {
        $data['producto'] = $this->model->getProducto($id_producto);
        $id_categoria = $data['producto']['id_categoria'];
        $data['relacionados'] = $this->model->getAleatorios($id_categoria, $data['producto']['id']);
        $data['title'] = $data['producto']['nombre'];
        $this->views->getView('principal', "detail", $data);
    }
    //vista category
    public function categorias($id_categoria)
    {
        $data['productos'] = $this->model->getProductosCat($id_categoria);
        $data['title'] = 'Categorias';
        $this->views->getView('principal', "categorias", $data);
    }
    //vista contact
    public function contactos($id_Contactos)
    {
        $data['contact'] = $this->model->getProductos($id_Contactos);
        $data['title'] = 'Contactos';
        $this->views->getView('principal', "contact", $data);
    }
    public function deseo()
    {
        $data['title'] = 'Tu lista de deseo';
        $this->views->getView('principal', "deseo", $data);
    }
    public function listaProductos()
    {
        $datos = file_get_contents('php://input');
        $json = json_decode($datos, true);
        $array ['productos']= array();
        $total = 0.00;
        foreach($json as $producto){
            $result = $this->model->getProducto($producto['idProducto']);
            $data['id'] = $result['id'];
            $data['nombre'] = $result['nombre'];
            $data['precio'] = $result['precio'];
            $data['cantidad'] = $producto['cantidad'];
            $data['imagen'] = $result['imagen'];
            $subTotal = $result['precio']* $producto['cantidad'];
            //$data['subTotal'] = number_format($result['precio']* $producto['cantidad'], 2);
            $data['subTotal'] = number_format($subTotal, 2);
            array_push($array ['productos'], $data);
            $total += $subTotal;
        }
        $array['total'] = number_format($total,2);
        $array['totalPaypal'] = $total;
        $array['moneda'] = MONEDA;
        echo json_encode($array, JSON_UNESCAPED_UNICODE);
        die();
    }

    public function busqueda($valor)
        {
            $data = $this->model->getBusqueda($valor);
            echo json_encode($data, JSON_UNESCAPED_UNICODE);
        die();
        }
    
}

