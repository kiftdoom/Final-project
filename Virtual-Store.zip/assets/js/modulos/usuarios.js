const nuevo = document.querySelector('#nuevo_registro');
document.addEventListener("DOMContentLoaded", function() {
    $('#tblUsuarios').DataTable({
        ajax: {
            url: base_url + 'usuarios/listar',
            dataSrc: ''
        },
        columns: [
            { data: 'id' },
            { data: 'nombres' },
            { data: 'apellidos' },
            { data: 'correo' },
            { data: 'perfil' }
        ],
        dom: 'Bfrtip', 
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print' 
        ]
    });
    
    nuevo.addEventListener("click", function() {
        document.querySelector('#id').value = '';
        document.querySelector('#nombre').value = '';
        document.querySelector('#imagen').value = '';
        titleModal.textContent = "NUEVA CATEGORIA";
        btnAccion.textContent = 'Registrar';
        frm.reset();
        myModal.show();
    })
});



