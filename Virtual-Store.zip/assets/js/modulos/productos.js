const frm = document.querySelector("#frmRegistro");
const btnAccion = document.querySelector("#btnAccion");
let tblProductos;

var firstTabEl = document.querySelector('#nav-tab button:last-child')
var firstTab = new bootstrap.Tab(firstTabEl)

document.addEventListener("DOMContentLoaded", function() {
    tblProductos = $("#tblProductos").DataTable({
        ajax: {
            url: base_url + "productos/listar",
            dataSrc: ""
        },
        columns: [
            { data: 'id' },
            { data: 'nombre' },
            { data: 'precio' },
            { data: 'cantidad' },
            { data: 'imagen' },
            { data: 'accion' }
        ],
        dom: 'Bfrtip',
        buttons: ['excel', 'pdf', 'csv']
    });

    // Submit productos
    frm.addEventListener("submit", function(e) {
        e.preventDefault();
        let data = new FormData(this);
        const url = base_url + "productos/registrar";
        const http = new XMLHttpRequest();
        http.open("POST", url, true);
        http.send(data);
        http.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                try {
                    const res = JSON.parse(this.responseText);
                    if (res.icono == "success") {
                        frm.reset();
                        tblProductos.ajax.reload();
                        document.querySelector('#imagen').value = '';
                    }
                    Swal.fire("Aviso", res.msg.toUpperCase(), res.icono);
                } catch (e) {
                    console.error("Error parsing JSON:", e);
                    Swal.fire("Error", "Respuesta inválida del servidor", "error");
                }
            }
        };
    });
});

function editPro(idPro) {
    const url = base_url + "productos/edit/" + idPro;
    const http = new XMLHttpRequest();
    http.open("GET", url, true);
    http.send();
    http.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            try {
                console.log("Response from server: ", this.responseText);
                const res = JSON.parse(this.responseText);
                
                if (res.id && res.nombre && res.precio && res.cantidad && res.id_categoria && res.descripcion && res.imagen) {
                    document.querySelector('#id').value = res.id;
                    document.querySelector('#nombre').value = res.nombre;
                    document.querySelector('#precio').value = res.precio;
                    document.querySelector('#cantidad').value = res.cantidad;
                    document.querySelector('#categorias').value = res.id_categoria;
                    document.querySelector('#descripcion').value = res.descripcion;
                    document.querySelector('#imagen_actual').value = res.imagen;
                    btnAccion.textContent = 'Actualizar';
                    firstTab.show();
                } else {
                    console.error("Datos incompletos recibidos:", res);
                    Swal.fire("Error", "Datos incompletos recibidos del servidor", "error");
                }
            } catch (e) {
                console.error("Error parsing JSON:", e, this.responseText);
                Swal.fire("Error", "Respuesta inválida del servidor", "error");
            }
        } else if (this.readyState == 4) {
            console.error("Error del servidor, status:", this.status);
            Swal.fire("Error", "Error del servidor", "error");
        }
    };
}

function eliminarPro(idPro) {
    Swal.fire({
        title: "Aviso?",
        text: "Está seguro de eliminar el registro!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Sí, Eliminar!"
    }).then((result) => {
        if (result.isConfirmed) {
            const url = base_url + "productos/delete/" + idPro;
            const http = new XMLHttpRequest();
            http.open("GET", url, true);
            http.send();
            http.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    try {
                        const res = JSON.parse(this.responseText);
                        if (res.icono == "success") {
                            tblProductos.ajax.reload();
                        }
                        Swal.fire("Aviso", res.msg.toUpperCase(), res.icono);
                    } catch (e) {
                        console.error("Error parsing JSON:", e);
                        Swal.fire("Error", "Respuesta inválida del servidor", "error");
                    }
                }
            };
        }
    });
}
