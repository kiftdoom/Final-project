let buttons = [{
    
    extend: 'excelHtml5',
    footer: true,


    text: '<span class="badge bg-success"><i class="fas fa-file-excel"></i></span>'
},

{
    extend: 'pdfHtml5',
    download: 'open',
    footer: true,
    text: '<span class="badge  bg-danger"><i class="fas fa-file-pdf"></i></span>',
    exportOptions: {
        columns: [0, ':visible']
    }
},
{
    extend: 'copyHtml5',
    footer: true,
    text: '<span class="badge  bg-primary"><i class="fas fa-copy"></i></span>',
    exportOptions: {
        columns: [0, ':visible']
    }
},
{
    extend: 'print',
    footer: true,
    text: '<span class="badge bg-light"><i class="fas fa-print"></i></span>'
},

{
    extend: 'csvHtml5',
    footer: true,
    filename: 'Export_File_csv',
    text: '<span class="badge  bg-success"><i class="fas fa-file-csv"></i></span>'
}
]

let dom = "<'row'<'col-sm-4'l><'col-sm-4 text-center'B><'col-sm-4'f>>" +
"<'row'<'col-sm-12'tr>>" +
"<'row'<'col-sm-5'i><'col-sm-7'p>>";