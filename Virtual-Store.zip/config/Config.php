<?php
const BASE_URL = "http://localhost/Vitual-Store/";
const HOST = "localhost";
const USER = "root";
const PASS = "";
const DB = "vitual_store";
const CHARSET = "charset=utf8";
const TITLE = "SHOP";
const MONEDA = "USD";
const CLIENTE_ID = "AbEAh_K8ypgLT06AoExJ1qhoHp0G_D-iUay-dByLkMfRRyG_5CJ5OmvrosbsYATUzm_1lppJinP19G1z";

?>